package server;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import environment.LocalBoard;
import remote.ActionResult;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static final int SERVER_PORT = 19934;
    private LocalBoard board;

    public Server(LocalBoard board) {
        this.board = board;
    }

    public LocalBoard getBoard() {
        return board;
    }

    public void start() {
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            System.out.println("Server is running on port " + SERVER_PORT);

            while (!Board.isFinished()) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    new ClientHandler(clientSocket, board).start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket clientSocket;
        private LocalBoard board;

        public ClientHandler(Socket clientSocket, LocalBoard board) {
            this.clientSocket = clientSocket;
            this.board = board;
        }

        @Override
        public void run() {
            try {
                ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
                ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());

                while (true) {
                    BoardPosition position = (BoardPosition) in.readObject();
                    ActionResult result = processPosition(position);
                    out.writeObject(result);
                    out.flush();
                    if (result.isGameEnded()) {
                        in.close();
                        out.close();
                        break;
                    }
                }

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        private ActionResult processPosition(BoardPosition position) {
            synchronized (board) {
                Cell cell = board.getCell(position);
                if (cell.isOccupiedByObstacle()) {
                    cell.removeObstacle();
                    return new ActionResult(true, Board.isFinished());
                } else if (cell.isOccupiedBySnake() && cell.getOcuppyingSnake().wasKilled()) {
                    cell.removeSnake(cell.getOcuppyingSnake());
                    return new ActionResult(true, Board.isFinished());
                } else {
                    return new ActionResult(false, Board.isFinished());
                }
            }
        }
    }
}
