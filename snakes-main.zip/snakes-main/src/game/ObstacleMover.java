package game;

import environment.Board;
import environment.LocalBoard;

import java.util.concurrent.BrokenBarrierException;

public class ObstacleMover implements Runnable {
    private final Obstacle obstacle;
    private final Board board;

    public ObstacleMover(Obstacle obstacle, LocalBoard board) {
        super();
        this.obstacle = obstacle;
        this.board = board;
    }

    public void move(Obstacle obstacle) {
        obstacle.getOccupyingCell().removeObstacle();
        board.addGameElement(obstacle);
        obstacle.decrementRemainingMoves();
        board.setChanged();
    }

    @Override
    public void run() {

        try {
            while (obstacle.getRemainingMoves() > 0) {
                Thread.sleep(Obstacle.getObstacleMoveInterval());
                move(obstacle);
            }
            System.out.println("Obstacle waiting for barrier");
            board.getBarrier().await();
        } catch (InterruptedException | BrokenBarrierException e) {
            throw new RuntimeException(e);
        }
    }
}
