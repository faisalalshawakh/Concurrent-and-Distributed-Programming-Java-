package game;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import environment.LocalBoard;

import java.util.List;
import java.util.Random;


public class AutomaticSnake extends Snake {
    private boolean toReposition = false;


    public AutomaticSnake(int id, LocalBoard board) {
        super(id, board);

    }

    private Cell pickCandidateCell(List<BoardPosition> freePositions) {
        Cell toReturn;

        if (toReposition) {
            // if movement to unlock snake is required we chose a random valid cell
            toReturn = getBoard().getCell(freePositions.get(new Random().nextInt(freePositions.size())));
            toReposition = false;
        } else {
            // regular snake movement towards goal
            toReturn = getBoard().getCell(getBoard().selectPositionClosestToGoal(freePositions));
        }
        return toReturn;
    }


    @Override
    public void run() {
        Board board = getBoard();

        doInitialPositioning();
        while (!Board.isFinished() && !interrupted() && !wasKilled()) {
            try {
                Thread.sleep(Board.PLAYER_PLAY_INTERVAL);
                List<BoardPosition> neighbourPositions = board.getNeighboringPositions(cells.getLast()); // head neighbours
                List<BoardPosition> freePositions = board.getFreePositions(neighbourPositions, this);
                if (freePositions.isEmpty())
                    break;  // returns null if movement is impossible
                Cell nextCell = pickCandidateCell(freePositions);
                move(nextCell);
            } catch (InterruptedException e) {
                toReposition = true;
            }
        }
    }
}


