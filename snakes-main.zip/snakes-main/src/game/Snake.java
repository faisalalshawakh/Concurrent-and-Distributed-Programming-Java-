package game;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;

import java.util.LinkedList;

public abstract class Snake extends Thread {
    private boolean killed = false;
    protected LinkedList<Cell> cells = new LinkedList<Cell>();
    protected int size = 5;
    private int id;
    private Board board;

    public Snake(int id, Board board) {
        this.id = id;
        this.board = board;
    }

    public void addSize(int goalAmount) {
        this.size += goalAmount;
    }


    public void killSnake() {
        killed = true;
        System.out.println("Snake " + getIdentification() + " was killed at position: " + getCells().getLast().getPosition());
    }

    public boolean wasKilled() {
        return killed;
    }

    public int getSize() {
        return size;
    }

    public int getIdentification() {
        return id;
    }

    public int getCurrentLength() {
        return cells.size();
    }

    public LinkedList<Cell> getCells() {
        return cells;
    }

    protected void move(Cell cell) throws InterruptedException {
        if (cell.isOccupiedByGoal()) {
            Goal goal = cell.getGoal();
            this.addSize(goal.captureGoal());
            cell.removeGoal();
        } else if (cell.isOccupiedByKiller()) {
            killSnake();
        }
        cell.request(this);

        cells.addLast(cell);
        if (cells.size() > size) { // Stops snake growth when size is met
            cells.removeFirst().release();
        }
        board.setChanged();
    }

    protected void doInitialPositioning() {
        int snakePositionX = 0;
        int snakePositionY = (int) (Math.random() * Board.HEIGHT); // The game starts with the snake at a random position of the first column

        BoardPosition snakePosition = new BoardPosition(snakePositionX, snakePositionY);

        try {
            board.getCell(snakePosition).request(this); // Add snake reference to Cell
        } catch (InterruptedException error) {
            error.printStackTrace();
        }
        cells.add(board.getCell(snakePosition)); // Add snake to the board (LinkedList)

        System.out.println("Snake " + getIdentification() + " starting at: " + getCells().getLast().getPosition());
    }

    public Board getBoard() {
        return board;
    }

    // Utility method to return cells occupied by snake as a list of BoardPosition
    // Used in GUI. Do not alter
    public synchronized LinkedList<BoardPosition> getPath() {
        LinkedList<BoardPosition> coordinates = new LinkedList<BoardPosition>();
        for (Cell cell : cells) {
            coordinates.add(cell.getPosition());
        }

        return coordinates;
    }
}
