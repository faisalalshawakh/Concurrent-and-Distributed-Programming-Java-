package game;

import environment.Board;

public class Killer extends GameElement {
    private Board board;

    public Killer(Board board) {
        this.board = board;
    }

}
