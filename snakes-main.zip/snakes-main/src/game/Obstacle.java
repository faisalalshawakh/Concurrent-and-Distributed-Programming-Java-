package game;

import environment.Board;
import environment.Cell;

public class Obstacle extends GameElement {


    private static final int NUM_MOVES = 3;
    private static final int OBSTACLE_MOVE_INTERVAL = 400;
    private int remainingMoves = NUM_MOVES;
    private Board board;
    private Cell occupyingCell;

    public Obstacle(Board board) {
        super();
        this.board = board;
    }

    public int getRemainingMoves() {
        return remainingMoves;
    }

    public void decrementRemainingMoves() {
        remainingMoves--;
        System.out.println(Thread.currentThread() + ": Obstacle has " + remainingMoves + " moves left");
    }

    public static int getObstacleMoveInterval() {
        return OBSTACLE_MOVE_INTERVAL;
    }

    public void setOccupyingCell(Cell cell) {
        occupyingCell = cell;
    }

    public Cell getOccupyingCell() {
        return occupyingCell;
    }
}
