package game;

import environment.Board;

public class Goal extends GameElement {
    private int value = 1;
    private Board board;
    public static final int MAX_VALUE = 10;

    public Goal(Board board) {
        this.board = board;
    }

    public int getValue() {
        return value;
    }

    public void incrementValue() {
        if (value < MAX_VALUE) {
            value++;
        }
    }


    public int captureGoal() {
        incrementValue();
        if (value < MAX_VALUE) {
            board.addGameElement(this);
            System.out.println("Added goal with value: " + value);
        } else {
            Board.setFinished();
        }
        return value;
    }
}
