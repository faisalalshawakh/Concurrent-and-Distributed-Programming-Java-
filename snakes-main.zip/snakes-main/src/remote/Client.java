package remote;

import environment.Board;
import environment.BoardPosition;
import server.Server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

import static environment.Board.REMOTE_REFRESH_INTERVAL;

public class Client {

    private static final String SERVER_ADDRESS = "localhost";

    public static void start() {
        try {
            Socket socket = new Socket(InetAddress.getByName(SERVER_ADDRESS), Server.SERVER_PORT);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

            while (true) {
                BoardPosition position = Board.getRandomPosition();
                out.writeObject(position);
                out.flush();
                ActionResult result = (ActionResult) in.readObject();
                if (result.wasSuccessful()) {
                    System.out.println("Obstacle successfully deleted from position: " + position);
                }

                if (result.isGameEnded()) {
                    in.close();
                    out.close();
                    break;
                }
                Thread.sleep(REMOTE_REFRESH_INTERVAL);
            }

        } catch (IOException | ClassNotFoundException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
