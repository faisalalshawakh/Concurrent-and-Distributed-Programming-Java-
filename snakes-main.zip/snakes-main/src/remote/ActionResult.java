package remote;


import java.io.Serializable;

public class ActionResult implements Serializable {
    private static final long serialVersionUID = 1L; // Optional, just to be sure that serialized object is compared with the ID of the class attempting to deserialize it
    private boolean wasSuccessful;
    private boolean gameEnded;

    public ActionResult(boolean wasSuccessful, boolean gameEnded) {
        this.wasSuccessful = wasSuccessful;
        this.gameEnded = gameEnded;
    }

    public boolean wasSuccessful() {
        return wasSuccessful;
    }

    public boolean isGameEnded() {
        return gameEnded;
    }
}

