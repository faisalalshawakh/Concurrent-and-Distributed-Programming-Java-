package environment;


import game.*;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Cell {
    private BoardPosition position;
    private Snake ocuppyingSnake = null;
    private GameElement gameElement = null;
    private final Lock lock = new ReentrantLock();
    private Condition waitForCellToBeFree = lock.newCondition();

    public Cell(BoardPosition position) {
        super();
        this.position = position;
    }


    public BoardPosition getPosition() {
        return position;
    }

    @Override
    public String toString() {
        return "" + position;
    }

    public void request(Snake snake) throws InterruptedException {
        /**
         * Waits until the position that the Snake wants to occupy is free.
         */
        lock.lock();
        try {
            while (isOccupied()) {
                waitForCellToBeFree.await();
            }
            ocuppyingSnake = snake;
        } finally {
            lock.unlock();
        }
    }

    public void release() {
        lock.lock();
        try {
            ocuppyingSnake = null;
            waitForCellToBeFree.signalAll();
        } finally {
            lock.unlock();
        }
    }


    public boolean isOccupiedBySnake() {
        lock.lock();
        try {
            return ocuppyingSnake != null;
        } finally {
            lock.unlock();
        }
    }

    public boolean isOccupiedByObstacle() {
        lock.lock();
        try {
            return gameElement instanceof Obstacle;
        } finally {
            lock.unlock();
        }
    }

    public boolean isOccupiedByGoal() {
        lock.lock();
        try {
            return gameElement instanceof Goal;
        } finally {
            lock.unlock();
        }
    }

    public boolean isOccupiedByKiller() {
        lock.lock();
        try {
            return gameElement instanceof Killer;
        } finally {
            lock.unlock();
        }
    }

    public boolean isOccupied() {
        lock.lock();
        try {
            return isOccupiedBySnake() || isOccupiedByObstacle() || isOccupiedByGoal() || isOccupiedByKiller();
        } finally {
            lock.unlock();
        }
    }


    public void setGameElement(GameElement element) {
        lock.lock();
        try {
            gameElement = element;
        } finally {
            lock.unlock();
        }
    }

    public GameElement getGameElement() {
        lock.lock();
        try {
            return gameElement;
        } finally {
            lock.unlock();
        }
    }


    public Snake getOcuppyingSnake() {
        lock.lock();
        try {
            return ocuppyingSnake;
        } finally {
            lock.unlock();
        }
    }

    public Goal getGoal() {
        lock.lock();
        try {
            return (Goal) gameElement;
        } finally {
            lock.unlock();
        }
    }

    public void removeGoal() {
        lock.lock();
        try {
            gameElement = null;
            waitForCellToBeFree.signalAll();
        } finally {
            System.out.println(Thread.currentThread() + ": Goal removed");
            lock.unlock();
        }
    }

    public void removeObstacle() {
        lock.lock();
        try {
            gameElement = null;
            waitForCellToBeFree.signalAll();
        } finally {
            lock.unlock();
        }
    }


    public void removeSnake(Snake snake) {
        lock.lock();
        try {
            LinkedList<Cell> snakeCells = snake.getCells();
            for (Cell snakeCell : snakeCells) {
                snakeCell.release();
            }
            snake.getCells().clear();
            waitForCellToBeFree.signalAll();
        } finally {
            System.out.println(Thread.currentThread() + ": Snake removed");
            lock.unlock();
        }
    }
}
