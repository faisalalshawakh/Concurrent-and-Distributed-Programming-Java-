package environment;

import game.AutomaticSnake;
import game.Obstacle;
import game.ObstacleMover;
import game.Snake;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocalBoard extends Board {

    private static final int NUM_SNAKES = 6;
    private static final int NUM_OBSTACLES = 25;
    private static final int NUM_SIMULTANEOUS_MOVING_OBSTACLES = 3;

    public LocalBoard() {
        // Place game elements and snakes
        for (int i = 0; i < NUM_SNAKES; i++) { // add snakes
            AutomaticSnake snake = new AutomaticSnake(i, this);
            addSnake(snake);
        }
        addObstacles(NUM_OBSTACLES);
        addGoal();
        System.out.println("All elements placed");
    }

    public void stopSnakes() {
        for (Snake s : getSnakes()) {
            s.interrupt();
        }
    }


    public void init() {
        // lock is done one the cell
        for (Snake s : getSnakes()) // start all snakes threads
            s.start();

        // only 3 threads running at the same time
        ExecutorService threadPool = Executors.newFixedThreadPool(NUM_SIMULTANEOUS_MOVING_OBSTACLES);
        for (Obstacle obstacle : getObstacles()) {
            // create obstacle movers and add them to the thread pool
            threadPool.submit(new ObstacleMover(obstacle, this));
        }
    }


    // Ignore these methods: only for remote players, which are not present in this project
    @Override
    public void handleKeyPress(int keyCode) {
        // do nothing... No keys relevant in local game
    }

    @Override
    public void handleKeyRelease() {
        // do nothing... No keys relevant in local game
    }

}
