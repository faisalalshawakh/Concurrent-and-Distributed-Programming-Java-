package environment;

import game.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.concurrent.CyclicBarrier;

// Class is abstract to allow the creation of other kinds of Board, which is not necessary in this project.
public abstract class Board extends Observable {
    protected Cell[][] cells;
    private BoardPosition goalPosition;
    public static final long PLAYER_PLAY_INTERVAL = 100;
    public static final long REMOTE_REFRESH_INTERVAL = 200;
    public static final int WIDTH = 30;
    public static final int HEIGHT = 30;
    protected LinkedList<Snake> snakes = new LinkedList<>();
    protected static boolean isFinished = false;
    public static final int NUMBER_WAITERS = 3;
    private LinkedList<Obstacle> obstacles = new LinkedList<>(); // TODO: copy cat
    protected CyclicBarrier barrier = new CyclicBarrier(NUMBER_WAITERS, this::addKiller);

    protected Board() {
        cells = new Cell[WIDTH][HEIGHT];
        for (int x = 0; x < WIDTH; x++) {
            for (int y = 0; y < HEIGHT; y++) {
                cells[x][y] = new Cell(new BoardPosition(x, y));
            }
        }
    }

    public abstract void stopSnakes();

    public Cell getCell(BoardPosition cellCoord) {
        return cells[cellCoord.x][cellCoord.y];
    }

    public static BoardPosition getRandomPosition() {
        return new BoardPosition((int) (Math.random() * HEIGHT), (int) (Math.random() * HEIGHT));
    }

    public BoardPosition getGoalPosition() {
        return goalPosition;
    }

    public void setGoalPosition(BoardPosition goalPosition) {
        this.goalPosition = goalPosition;
        System.out.println("Goal placed at: " + goalPosition);
    }

    public static void setFinished() {
        isFinished = true;
        System.out.println("Game won!");
    }

    public synchronized void addGameElement(GameElement gameElement) {
        /**
         * Add game elements (snakes, obstacles, killers) to the Board
         **/
        BoardPosition boardPosition = getRandomPosition();
        Cell cellPosition = getCell(boardPosition);

        if (!cellPosition.isOccupied()) {
            cellPosition.setGameElement(gameElement);
            if (gameElement instanceof Obstacle obstacle) {
                obstacle.setOccupyingCell(cellPosition);
            } else if (gameElement instanceof Goal) {
                setGoalPosition(boardPosition);
            }
        } else {
            addGameElement(gameElement);
        }
    }


    public CyclicBarrier getBarrier() {
        return barrier;
    }


    public void addKiller() {
        addGameElement(new Killer(this));
        System.out.println("Killer added");
    }

    public List<BoardPosition> getNeighboringPositions(Cell cell) {
        ArrayList<BoardPosition> possibleCells = new ArrayList<BoardPosition>();
        BoardPosition pos = cell.getPosition();
        if (pos.x > 0)
            possibleCells.add(pos.getCellLeft());
        if (pos.x < WIDTH - 1)
            possibleCells.add(pos.getCellRight());
        if (pos.y > 0)
            possibleCells.add(pos.getCellAbove());
        if (pos.y < HEIGHT - 1)
            possibleCells.add(pos.getCellBelow());
        return possibleCells;

    }

    public List<BoardPosition> getFreePositions(List<BoardPosition> boardPositions, Snake snake) {
        List<BoardPosition> freePositions = new ArrayList<>();

        for (BoardPosition boardPosition : boardPositions) {
            Snake snakeAtPos = getCell(boardPosition).getOcuppyingSnake();
            if (!snake.equals(snakeAtPos)) {
                freePositions.add(boardPosition);
            }
        }
        return freePositions;
    }

    public BoardPosition selectPositionClosestToGoal(List<BoardPosition> possibleDestinations) {
        BoardPosition selectedPosition = possibleDestinations.getFirst();
        double distanceToGoal = selectedPosition.distanceTo(getGoalPosition());

        for (BoardPosition possibleDestination : possibleDestinations) {
            double currentDistanceToGoal = possibleDestination.distanceTo(getGoalPosition());
            if (currentDistanceToGoal < distanceToGoal) { // if cell is still null, it gets picked anyway
                distanceToGoal = currentDistanceToGoal;
                selectedPosition = possibleDestination;
            }
        }

        return selectedPosition;
    }

    protected void addGoal() {
        addGameElement(new Goal(this));
        System.out.println("Goal added");
    }

    protected void addObstacles(int numberObstacles) {
        getObstacles().clear(); // necessary when resetting obstacles
        while (numberObstacles > 0) {
            Obstacle obs = new Obstacle(this);
            addGameElement(obs);
            getObstacles().add(obs);
            numberObstacles--;
            System.out.println(Thread.currentThread() + ": Obstacle added");
        }
    }


    public LinkedList<Snake> getSnakes() {
        return snakes;
    }


    @Override
    public synchronized void setChanged() {
        super.setChanged();
        notifyObservers();
    }


    public static boolean isFinished() {
        return isFinished;

    }

    public LinkedList<Obstacle> getObstacles() {
        // percorrer cells e acumular obstáculos numa lista
        return obstacles;
    }


    public void addSnake(Snake snake) {
        snakes.add(snake);
    }


    public abstract void init();


    // Ignorar: para johador humano
    public abstract void handleKeyPress(int keyCode);

    public abstract void handleKeyRelease();


    protected void setCells(Cell[][] cells) {
        this.cells = cells;
    }

    public Cell[][] getCells() {
        return cells;
    }

}