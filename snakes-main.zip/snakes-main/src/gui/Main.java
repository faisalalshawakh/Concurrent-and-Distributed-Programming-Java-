package gui;

import environment.LocalBoard;
import remote.Client;
import server.Server;

public class Main {
    public static void main(String[] args) {
        LocalBoard board = new LocalBoard();
        SnakeGui game = new SnakeGui(board, 600, 0);
        game.init();

        // Start the server in a new thread
        Server server = new Server(board);
        new Thread(server::start).start();

        // Start multiple clients
        final int NUM_CLIENTS = 6; // or any number of clients you want to run
        for (int i = 0; i < NUM_CLIENTS; i++) {
            new Thread(Client::start).start();
        }
    }

}
